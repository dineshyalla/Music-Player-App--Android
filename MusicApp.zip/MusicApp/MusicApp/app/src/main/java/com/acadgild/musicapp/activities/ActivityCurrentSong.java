package com.acadgild.musicapp.activities;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

import com.acadgild.musicapp.R;

/**
 * Created by AcadGildMentor on 6/9/2015.
 */
public class ActivityCurrentSong extends ActionBarActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.act_current_song);


    }
}
